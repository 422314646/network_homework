urlData="http://ddns.cjoyin.top:32009/IOT/seqCodeGenerte.php/Device1/"
urlLogin="http://ddns.cjoyin.top:32009/IOT/auth.php/Auth/normalLogin"
